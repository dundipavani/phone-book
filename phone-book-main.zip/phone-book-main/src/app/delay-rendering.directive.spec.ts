import { DelayRenderingDirective } from './delay-rendering.directive';

describe('DelayRenderingDirective', () => {
  it('should create an instance', () => {
    const directive = new DelayRenderingDirective();
    expect(directive).toBeTruthy();
  });
});
